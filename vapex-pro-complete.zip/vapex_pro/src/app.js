import 'dotenv/config';
import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import compression from 'compression';
import { connectDB } from './utils/database.js';
import { errorHandler } from './middleware/errorHandler.js';
import { requestLogger } from './middleware/requestLogger.js';
import { setupWebSocket } from './services/websocket.js';
import { setupMQTT } from './services/mqtt.js';
import { startCronJobs } from './services/cron.js';

// Import routes
import authRoutes from './routes/auth.js';
import deviceRoutes from './routes/devices.js';
import puffRoutes from './routes/puffs.js';
import analyticsRoutes from './routes/analytics.js';
import smartModesRoutes from './routes/smartModes.js';
import goalsRoutes from './routes/goals.js';
import findRoutes from './routes/find.js';
import settingsRoutes from './routes/settings.js';
import flavorRoutes from './routes/flavors.js';
import coilRoutes from './routes/coils.js';
import liquidRoutes from './routes/liquids.js';
import cloudRoutes from './routes/cloud.js';
import userRoutes from './routes/users.js';
import healthRoutes from './routes/health.js';
import { logger } from './utils/logger.js';
import { assertProductionEnv } from './config/env.js';
import { getProductionCorsOrigins } from './config/cors.js';

const app = express();
const PORT = process.env.PORT || 3000;
let server;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      connectSrc: ["'self'", 'ws:', 'wss:', 'https://fonts.googleapis.com'],
      imgSrc: ["'self'", 'data:'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    }
  }
}));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? getProductionCorsOrigins()
    : true,
  credentials: true
}));

// Rate limiting (always on; tune with RATE_LIMIT_MAX_REQUESTS)
const rateLimitMax = Math.max(
  1,
  Number.parseInt(process.env.RATE_LIMIT_MAX_REQUESTS ?? '', 10) ||
    (process.env.NODE_ENV === 'production' ? 100 : 1000)
);
const limiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute window
  max: rateLimitMax,
  message: { success: false, error: 'Too many requests, please try again later.', code: 'RATE_LIMIT' },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Body parsing & compression
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(compression());

// Request logging
app.use(requestLogger);

// API Versioning
const API_V1 = '/api/v1';

// Routes
app.use(`${API_V1}/auth`, authRoutes);
app.use(`${API_V1}/devices`, deviceRoutes);
app.use(`${API_V1}/puffs`, puffRoutes);
app.use(`${API_V1}/analytics`, analyticsRoutes);
app.use(`${API_V1}/smart-modes`, smartModesRoutes);
app.use(`${API_V1}/goals`, goalsRoutes);
app.use(`${API_V1}/find`, findRoutes);
app.use(`${API_V1}/settings`, settingsRoutes);
app.use(`${API_V1}/flavors`, flavorRoutes);
app.use(`${API_V1}/coils`, coilRoutes);
app.use(`${API_V1}/liquids`, liquidRoutes);
app.use(`${API_V1}/cloud`, cloudRoutes);
app.use(`${API_V1}/users`, userRoutes);
app.use(`${API_V1}/health`, healthRoutes);

// Serve frontend
app.use(express.static(join(__dirname, '../public')));

// Root endpoint - serve the dashboard
app.get('/', (req, res) => {
  res.sendFile(join(__dirname, '../public/index.html'));
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({
      success: false,
      error: 'Endpoint not found',
      code: 'NOT_FOUND',
      path: req.originalUrl
    });
  }

  return res.sendFile(join(__dirname, '../public/index.html'));
});

// Error handling (must be last)
app.use(errorHandler);

// Graceful shutdown
const gracefulShutdown = (signal) => {
  logger.info(`${signal} received. Starting graceful shutdown...`);
  if (!server) {
    process.exit(0);
    return;
  }
  server.close(() => {
    logger.info('HTTP server closed.');
    process.exit(0);
  });
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle unhandled rejections
process.on('unhandledRejection', (err) => {
  logger.error({ err }, 'Unhandled Promise Rejection');
  process.exit(1);
});

// Start server
const startServer = async () => {
  try {
    assertProductionEnv();

    // Connect to database
    await connectDB();
    logger.info('Database connected successfully');

    // Start HTTP server
    server = app.listen(PORT, () => {
      logger.info(`VAPEX API server running on port ${PORT}`);
      logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
    });
    server.on('error', (err) => {
      logger.error({ err }, 'HTTP server listen error');
      process.exit(1);
    });

    // Setup WebSocket
    setupWebSocket(server);
    logger.info('WebSocket server initialized');

    // Setup MQTT
    setupMQTT();
    logger.info('MQTT client initialized');

    // Start cron jobs
    startCronJobs();
    logger.info('Cron jobs started');

    return server;
  } catch (error) {
    logger.error({ error }, 'Failed to start server');
    process.exit(1);
  }
};

startServer();

export { app, logger };
