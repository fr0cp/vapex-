import express from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';
import { authenticate } from '../middleware/auth.js';
import { validate, schemas } from '../middleware/validate.js';
import { AppError } from '../middleware/errorHandler.js';
import { getJwtSecret } from '../config/env.js';
import { logger } from '../utils/logger.js';

const router = express.Router();
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '30d';

// Register
router.post('/register', validate(schemas.register), async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      throw new AppError('Email already registered', 409, 'EMAIL_EXISTS');
    }

    const user = await User.create({
      name,
      email,
      password,
      avatar: name.split(' ').map(n => n[0]).join('').toUpperCase()
    });

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      getJwtSecret(),
      { expiresIn: JWT_EXPIRES_IN }
    );

    const refreshToken = jwt.sign(
      { userId: user._id, type: 'refresh' },
      getJwtSecret(),
      { expiresIn: JWT_REFRESH_EXPIRES_IN }
    );

    logger.info({ userId: user._id }, 'New user registered');

    res.status(201).json({
      success: true,
      token,
      refreshToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        memberSince: user.memberSince
      }
    });
  } catch (error) {
    next(error);
  }
});

// Login
router.post('/login', validate(schemas.login), async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      throw new AppError('Invalid email or password', 401, 'INVALID_CREDENTIALS');
    }

    const isValid = await user.comparePassword(password);
    if (!isValid) {
      throw new AppError('Invalid email or password', 401, 'INVALID_CREDENTIALS');
    }

    user.lastLogin = new Date();
    await user.save();

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      getJwtSecret(),
      { expiresIn: JWT_EXPIRES_IN }
    );

    const refreshToken = jwt.sign(
      { userId: user._id, type: 'refresh' },
      getJwtSecret(),
      { expiresIn: JWT_REFRESH_EXPIRES_IN }
    );

    logger.info({ userId: user._id }, 'User logged in');

    res.json({
      success: true,
      token,
      refreshToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        memberSince: user.memberSince,
        preferences: user.preferences
      }
    });
  } catch (error) {
    next(error);
  }
});

// Refresh token
router.post('/refresh', validate(schemas.refreshToken), async (req, res, next) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw new AppError('Refresh token required', 400, 'NO_REFRESH_TOKEN');
    }

    const decoded = jwt.verify(refreshToken, getJwtSecret());

    if (decoded.type !== 'refresh') {
      throw new AppError('Invalid refresh token', 401, 'INVALID_REFRESH_TOKEN');
    }

    const user = await User.findById(decoded.userId);
    if (!user) {
      throw new AppError('User not found', 401, 'USER_NOT_FOUND');
    }

    const newToken = jwt.sign(
      { userId: user._id, email: user.email },
      getJwtSecret(),
      { expiresIn: JWT_EXPIRES_IN }
    );

    res.json({
      success: true,
      token: newToken
    });
  } catch (error) {
    next(error);
  }
});

// Get current user
router.get('/me', authenticate, async (req, res) => {
  res.json({
    success: true,
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      avatar: req.user.avatar,
      memberSince: req.user.memberSince,
      preferences: req.user.preferences,
      memberDuration: req.user.memberDuration,
      cloudSync: req.user.cloudSync
    }
  });
});

// Logout (invalidate token on client side)
router.post('/logout', authenticate, async (req, res) => {
  logger.info({ userId: req.user._id }, 'User logged out');
  res.json({ success: true, message: 'Logged out successfully' });
});

export default router;
